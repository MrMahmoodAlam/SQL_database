Hello ,
Here in this repo. I have wrote a database with ER daigram image file, database code file, database text file.
There are total 4 files.
DatabaseImage 	- Design and Structure of the database .
Databse Code 	- SQL codes including relation with tables.
FullDataResultCode   - SQL query for getting all the result in the main table of databse.
WorldDatabase              -  Its a ER daigram in sql file formate.

How to use :
First run all the SQL code of "Databse Code"  that written inside this file
Second run "FullDataResultCode"   code inside this file.
Now you will get all the database Reult.

Thank you for reading this.